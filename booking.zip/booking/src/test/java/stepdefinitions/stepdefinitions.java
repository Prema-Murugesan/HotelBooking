package stepdefinitions;

import static org.junit.Assert.assertEquals;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;
import org.testng.AssertJUnit;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.HashMap;
import java.util.Map;

import automationLib.requestValues;
import automationLib.Utilities;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
//import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyExtractionOptions;
import io.restassured.response.ResponseOptions;

public class stepdefinitions extends Utilities{
	    private Response response;
	    private String username;
	    private String password;
	    
	    @Given("user hits endpoint {string}")
	    public void user_hits_endpoint(String url) {
	    	requestValues.setEndPoint(url);
	    }

	    @When("user enters {string} and {string}")
	    public void user_enters_and(String username, String password) {
	    	this.username = username;
	        this.password = password;
	       
	        String body = "{\n"
	                + "  \"username\": \"" + username + "\",\n"
	                + "  \"password\": \"" + password + "\"\n"
	                + "}";
	        response = requestSetup().body(body).post(requestValues.getEndPoint());
	        String token = response.jsonPath().getString("token");
	        requestValues.setToken(token);
	    }

	    @Then("the response status code should be {int}")
	    public void the_response_status_code_should_be(Integer code) {
	    	response.then().statusCode(code);	
	    }
	    
	    @When("user books the room with details {string},{string},{string},{string},{string},{string}")
	    public void user_books_the_room_with_details(String firstname, String lastname, String email, String phone, String checkin, String checkout) {
	    	
	    	int roomid = Integer.parseInt(generateRandomRoomId());
	    	requestValues.setFirstname("firstname");
	    	requestValues.setLastname("lastname");
	    	requestValues.setEmail("email");
	    	requestValues.setPhone("phone");
	    	requestValues.setCheckin("checkin");
	    	requestValues.setCheckout("checkout");
	    	requestValues.setRoomid(roomid);
	    	requestValues.setDepositpaid(false);
						
	    String body1 = "{\r\n"
	    		+ "    \"roomid\": \""+roomid+"\",\r\n"
	    		+ "    \"firstname\": \""+firstname+"\",\r\n"
	    		+ "    \"lastname\": \""+lastname+"\",\r\n"
	    		+ "    \"depositpaid\": false,\r\n"
	    		+ "    \"bookingdates\": {\r\n"
	    		+ "        \"checkin\": \""+checkin+"\",\r\n"
	    		+ "        \"checkout\": \""+checkout+"\"\r\n"
	    		+ "    },\r\n"
	    		+ "    \"email\": \""+email+"\",\r\n"
	    		+ "    \"phone\": \""+phone+"\"\r\n"
	    		+ "}";
	    
	    response = requestSetup().body(body1).post(requestValues.getEndPoint());
	    if(response.getStatusCode()==201)
	    {
	       int  bookingId = response.jsonPath().getInt("bookingid");
	       requestValues.setBookingId(bookingId);
	    }
	    }
	    
	    @When("user books the room with details {string},{string},{string},{string},{string},{string},{string}")
	    public void user_books_the_room_with_details(String firstname, String lastname, String email, String phone, String checkin, String checkout, String roomid) {
	    	int room = Integer.parseInt(roomid);
	    	requestValues.setFirstname("firstname");
	    	requestValues.setLastname("lastname");
	    	requestValues.setEmail("email");
	    	requestValues.setPhone("phone");
	    	requestValues.setCheckin("checkin");
	    	requestValues.setCheckout("checkout");
	    	requestValues.setRoomid(room);
	    	requestValues.setDepositpaid(false);
						
	    String body2 = "{\r\n"
	    		+ "    \"roomid\": \""+roomid+"\",\r\n"
	    		+ "    \"firstname\": \""+firstname+"\",\r\n"
	    		+ "    \"lastname\": \""+lastname+"\",\r\n"
	    		+ "    \"depositpaid\": false,\r\n"
	    		+ "    \"bookingdates\": {\r\n"
	    		+ "        \"checkin\": \""+checkin+"\",\r\n"
	    		+ "        \"checkout\": \""+checkout+"\"\r\n"
	    		+ "    },\r\n"
	    		+ "    \"email\": \""+email+"\",\r\n"
	    		+ "    \"phone\": \""+phone+"\"\r\n"
	    		+ "}";
	    
	    response = requestSetup().body(body2).post(requestValues.getEndPoint());
	    
	    }

	    @Then("the user should get response with {string}")
	    public void the_user_should_get_response_with(String errorMessage) {
	    	List<String> actualErrorMessage = response.jsonPath().getList("errors");
			assertEquals("Error message mismatch", errorMessage, actualErrorMessage.get(0));  
	}

}

