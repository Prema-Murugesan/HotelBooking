package stepdefinitions;

import static org.junit.Assert.assertEquals;
import java.util.List;
import java.util.Map;
import org.json.JSONObject;
import org.testng.AssertJUnit;

import com.fasterxml.jackson.core.JsonProcessingException;
import java.util.HashMap;
import java.util.Map;

import automationLib.requestValues;
import automationLib.Utilities;
import io.cucumber.datatable.DataTable;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.RestAssured;
//import io.restassured.module.jsv.JsonSchemaValidator;
import io.restassured.response.Response;
import io.restassured.response.ResponseBodyExtractionOptions;
import io.restassured.response.ResponseOptions;

public class stepdefinitions extends Utilities{
	    private Response response;
	    private String username;
	    private String password;
	    
	    @Given("user hits endpoint {string}")
	    public void user_hits_endpoint(String url) {
//	    	this.endpoint = url;
	    	requestValues.setEndPoint(url);
	    }

	    @When("user enters {string} and {string}")
	    public void user_enters_and(String username, String password) {
	    	this.username = username;
	        this.password = password;
	       
	        String body = "{\n"
	                + "  \"username\": \"" + username + "\",\n"
	                + "  \"password\": \"" + password + "\"\n"
	                + "}";
	        response = requestSetup().body(body).post(requestValues.getEndPoint());
	    }


	    @Then("the response status code should be {int}")
	    public void the_response_status_code_should_be(Integer code) {
	    	AssertJUnit.assertEquals(200, response.getStatusCode());	
	    }

	}

	

